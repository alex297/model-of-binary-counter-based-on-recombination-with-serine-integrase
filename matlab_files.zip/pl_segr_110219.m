N1=3000; M1=10; Ndil=7; pl=20;
% N1-cell number; M1-number of divisions between dilutions; Ndil-number of dilutions (division cycles);
% pl-number of plasmids; y0/y- number of LR plasmids before/after division
% backgr-background fluorescence

y=[ ]; Y1=[ ]; coun=[]; gis=zeros(pl+1,1); 
LR=4/20; %initial proportion of LR plasmids in each cell
y=zeros(N1,1)+round(pl*LR); y0=y; backgr=pl/100;
colormap('jet')

for i=1:N1
    for j=1:pl+1
        if (y(i)>=(j-1)) & (y(i)<j)
            gis(j)=gis(j)+1;
        end
    end
    siz=normrnd(1,0.1);
    n_SD=0.05; % SD of normal distribution 
    flu(i)=(y0(i)/2+y(i)+backgr)/pl/1.5*normrnd(1,n_SD); % flu - normalized fluoresence; n_SD - to fit to experimental shape
end    

flu_bin=[0.001:0.0001:0.01,0.02:0.01:2];

N=size(flu_bin,2); % number of bins for fluorescence measurements
colors = jet(N);
coun=zeros(N,1);
for i=1:N1
    for j=1:(N-1)
        if flu(i)>=flu_bin(j) & flu(i)<flu_bin(j+1)
            coun(j)=coun(j)+1;
        end
    end
    if flu(i)>=flu_bin(N)
    coun(N)=coun(N)+1;
    end
end

aHand = axes('parent', figure (101));
hold(aHand, 'on')
colors = jet(pl+1);
for i = 1:pl+1
    bar(i-1, gis(i)/N1, 'parent', aHand, 'facecolor', colors(i,:));
end
set(gcf, 'Position', [10, 10, 300, 200]);
xlabel('number of LR plasmids per cell','FontSize', 11);
ylabel('fraction of cells','FontSize', 11);
xlim([-1,21]);

    figure (102)
    bar(log10(flu_bin),coun,'k','BarWidth',4);
    set(gcf, 'Position', [100, 100, 300, 200]);
    ylabel('cell count');
    set(gca,'Xtick',-3:0.3); %// adjust manually; values in log scale
    set(gca,'Xticklabel',10.^get(gca,'Xtick')); %// use labels with linear value

for l=1:Ndil 
for m=1:M1
    for i=1:N1
        y0(i)=y(i); % before division
        if 2*y(i)<=pl % case of < half of mother plasmids in LR
            d1=0;
            for j=1:2*y(i)
                x1=round(rand);
                    if (x1>0.5)
                        d1=d1+1; % number of daughter LR plasmids
                    end
            end
        else
            d1=pl;
               for j=1:(2*pl-2*y(i))
                  x1=round(rand);
                    if (x1>0.5) 
                        d1=d1-1;
                    end
               end
        end
         y(i)=d1;
         Y1(i,m+1)=y(i);
    end
end
gis=zeros(pl+1,1);
for i=1:N1
    siz=normrnd(1,0.1);
    for j=1:pl+1
        if (y(i)>=(j-1)) & (y(i)<j)
            gis(j)=gis(j)+1;
        end
    end
    
    
    flu(i)=(y0(i)/2+y(i)+backgr)/pl/1.5*normrnd(1,n_SD);
end

aHand = axes('parent', figure (Ndil+l));
hold(aHand, 'on')
colors = jet(pl+1);
for i = 1:pl+1
    bar(i-1, gis(i)/N1, 'parent', aHand, 'facecolor', colors(i,:));
end
set(gcf, 'Position', [10, 10, 300, 200]);
xlabel('number of LR plasmids per cell','FontSize', 11);
ylabel('fraction of cells','FontSize', 11);
xlim([-1,21]);

gis=zeros(pl+1,1);

coun=zeros(N,1);
for i=1:N1
    for j=1:(N-1)
        if flu(i)>=flu_bin(j) & flu(i)<flu_bin(j+1)
            coun(j)=coun(j)+1;
        end
    end
    if flu(i)>=flu_bin(N)
    coun(N)=coun(N)+1;
    end
end

    figure (l)
    bar(log10(flu_bin),coun,'k','BarWidth',4);
    set(gcf, 'Position', [100, 100, 300, 200]);
    ylabel('cell count');
    set(gca,'Xtick',-3:0.3); 
    set(gca,'Xticklabel',10.^get(gca,'Xtick')); 

end


