Kr1=1; Kr2=1; Dtot=0.017; Ki=0.02; Kii=0.3; Kir=0.05; Kmod=3.4; Kmodr=1.9; Ks01=0.001; Ks02=0.007;
Ks1=0.1; Ks2=0.12; Ks3=0.1; Ks4=0.013; Kb1=0.02; Kb2=0.01; Kb3=0.025; Kb4=0.05;

k_dil=2; Ktet=0.01; ara_on=1; ara_off=1.2; period=24; kt=0.3;
k_tscr=120; k_int=2.7; ktet_tsl=4; krdf_tsl=230; k_rna=4; 

% time unit - hour
y0=[0*Dtot 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1*Dtot 0 0 0 0 0 0 0 0 0 0 0 0 0 0]; 
options = odeset('MaxStep',0.1);

N=60;
x=1:1:N;
fx1=0; stx=[]; sty=[]; 
for i=1:N
    sty(i)=1.08^(x(i))*10;
    stx(i)=1.08^(x(i))/10;
end
for j=1:N
    krdf_tsl(j)=sty(j);
    for i=1:N
        ktet_tsl(i)=stx(i);
        t=[0 24*10];
        [T, Y] = ode15s(@Model_tetR_110219,t,y0,options,Kii,Ki,Kir,Kb1,Kb2,Kb3,Kb4,Ks1,Ks2,Ks3,Ks4,Kr1,Kr2,Kmod,Kmodr,Ks01,Ks02,k_int,k_dil,Ktet,ara_on,ara_off,period,k_tscr,k_rna,ktet_tsl(i),krdf_tsl(j),kt);
        m=length(T);
        LRtot1(i,j)=(Y(m,1)+Y(m,6)+Y(m,8)+Y(m,9)+Y(m,11)+Y(m,13)+Y(m,15)+Y(m,18)+Y(m,22)+Y(m,28)+Y(m,29)+Y(m,30))/Dtot;
        BPtot1(i,j)=(Y(m,5)+Y(m,7)+Y(m,10)+Y(m,12)+Y(m,14)+Y(m,16)+Y(m,17)+Y(m,21)+Y(m,24)+Y(m,25)+Y(m,26)+Y(m,27)+Y(m,31)+Y(m,32)+Y(m,34)+Y(m,35)+Y(m,36))/Dtot;

        t=[0 24*9];
        [T, Y] = ode15s(@Model_tetR_110219,t,y0,options,Kii,Ki,Kir,Kb1,Kb2,Kb3,Kb4,Ks1,Ks2,Ks3,Ks4,Kr1,Kr2,Kmod,Kmodr,Ks01,Ks02,k_int,k_dil,Ktet,ara_on,ara_off,period,k_tscr,k_rna,ktet_tsl(i),krdf_tsl(j),kt);
        m=length(T);
        LRtot2(i,j)=(Y(m,1)+Y(m,6)+Y(m,8)+Y(m,9)+Y(m,11)+Y(m,13)+Y(m,15)+Y(m,18)+Y(m,22)+Y(m,28)+Y(m,29)+Y(m,30))/Dtot;
        BPtot2(i,j)=(Y(m,5)+Y(m,7)+Y(m,10)+Y(m,12)+Y(m,14)+Y(m,16)+Y(m,17)+Y(m,21)+Y(m,24)+Y(m,25)+Y(m,26)+Y(m,27)+Y(m,31)+Y(m,32)+Y(m,34)+Y(m,35)+Y(m,36))/Dtot;
        LRtot(i,j)=max(LRtot1(i,j),LRtot2(i,j));
        BPtot(i,j)=max(BPtot1(i,j),BPtot2(i,j));
        eff(i,j)=min(LRtot(i,j),BPtot(i,j));
    end
end

colormap('jet')
figure (1)
contourf(krdf_tsl,ktet_tsl,LRtot);
hold on;
xlabel('krdf_t_s_l, h-1','FontSize', 12);
ylabel('ktet_t_s_l, h-1','FontSize', 12);
title('LR');
colorbar; caxis([0 1]);

figure (2)
contourf(krdf_tsl,ktet_tsl,BPtot);
hold on;
xlabel('krdf_t_s_l, h-1','FontSize', 12);
ylabel('ktet_t_s_l, h-1','FontSize', 12);
title('BP');
colorbar; caxis([0 1]);

figure (3)
contourf(krdf_tsl,ktet_tsl,eff);
hold on;
xlabel('krdf_t_s_l, h-1','FontSize', 12);
ylabel('ktet_t_s_l, h-1','FontSize', 12);
title('min efficiency');
colorbar; caxis([0 1]);

%dlmwrite('tetR_map_LR_.txt',LRtot);
%dlmwrite('tetR_map_BP_.txt',BPtot);
%dlmwrite('tetR_map_eff_.txt',eff);
