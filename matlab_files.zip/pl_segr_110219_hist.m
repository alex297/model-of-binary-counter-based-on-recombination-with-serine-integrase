N1=3000; M1=10; Ndil=7; pl=20;
% N1-cell number; M1-number of divisions between dilutions; Ndil-number of dilutions (division cycles);
% pl-number of plasmids; y0/y- number of LR plasmids before/after division
% backgr-background fluorescence

y=[ ]; Y1=[ ]; coun=[]; gis=zeros(pl+1,1); 
LR=3/20; %initial proportion of LR plasmids in each cell
%LR=10/20;
%LR=17/20;
y=zeros(N1,1)+round(pl*LR); y0=y; backgr=pl/100;

for i=1:N1
    for j=1:pl+1
        if (y(i)>=(j-1)) & (y(i)<j)
            gis(j)=gis(j)+1;
        end
    end
end    

figure (101)
bar(0:pl,gis/N1,'k');
hold on;
xlabel('number of LR plasmids per cell','FontSize', 11);
ylabel('fraction of cells','FontSize', 11);
xlim([-1,21]);
set(gcf, 'Position', [10, 10, 300, 200]);

for l=1:Ndil 
for m=1:M1
    for i=1:N1
        y0(i)=y(i); % before division
        if 2*y(i)<=pl % case of < half of mother plasmids in LR
            d1=0;
            for j=1:2*y(i)
                x1=round(rand);
                    if (x1>0.5)
                        d1=d1+1; % number of daughter LR plasmids
                    end
            end
        else
            d1=pl;
               for j=1:(2*pl-2*y(i))
                  x1=round(rand);
                    if (x1>0.5) 
                        d1=d1-1;
                    end
               end
        end
         y(i)=d1;
         Y1(i,m+1)=y(i);
    end
end

gis=zeros(pl+1,1);
for i=1:N1
    siz=normrnd(1,0.1);
    for j=1:pl+1
        if (y(i)>=(j-1)) & (y(i)<j)
            gis(j)=gis(j)+1;
        end
    end
    
    
    flu(i)=(y0(i)/2+y(i)+backgr)/pl/1.5*normrnd(1,n_SD);
end
gis_fin=gis;
gis=zeros(pl+1,1);
coun=zeros(N,1);
end

figure (1)
bar(0:pl,gis_fin/N1,'k');
hold on;
xlabel('number of LR plasmids per cell','FontSize', 11);
ylabel('fraction of cells','FontSize', 11);
xlim([-1,21]);
set(gcf, 'Position', [10, 10, 300, 200]);
