% main model file, calling for ode file Model_tetR_f.m
Kr1=1; Kr2=1; Dtot=0.017; Ki=0.02; Kii=0.3; Kir=0.05; Kmod=3.4; Kmodr=1.9; Ks01=0.001; Ks02=0.007;
Ks1=0.1; Ks2=0.12; Ks3=0.1; Ks4=0.013; Kb1=0.02; Kb2=0.01; Kb3=0.025; Kb4=0.05; %Ks1,Ks3,Kb1,Kb3-dissociation constants

k_dil=2; Ktet=0.01; ara_on=0.5; ara_off=0.7; period=24; k_tscr=120; k_int=3; k_rna=4; kt=0.3;
ktet_tsl=0.3; krdf_tsl=4; % default parameters
%Ktet=10; % to switch off tetR inhibition
%kt=0.03; 
%ktet_tsl=3.4; krdf_tsl=800; % optimized parameters
%ara_on=0.5; ara_off=0.7; 
% time unit - hour; concentrations - mkM

% y(1)   LR
% y(2)   int
% y(3)   int2-rdf2
% y(4)   int2
% y(5)   PB-int2
% y(6)   LR-int2
% y(7)   PB-int4
% y(8)   LR-int4
% y(9)   LR-int4 synapse second
% y(10)  PB-int4 synapse 
% y(11)  LR-int4 synapse first
% y(12)  PB-int2-rdf2
% y(13)  LR-int2-rdf2
% y(14)  PB-int4-rdf4
% y(15)  LR-int4-rdf4
% y(16)  PB-int4-rdf4 synapse second
% y(17)  PB-int4-rdf4 synapse first
% y(18)  LR-int4-rdf4 synapse
% y(19)  int-rdf
% y(20)  int2-rdf
% y(21)  PB-int2-rdf
% y(22)  LR-int2-rdf
% y(23)  rdf
% y(24)  PB
% y(25)  PB-int4-rdf
% y(26)  PB-int4-rdf2
% y(27)  PB-int4-rdf3
% y(28)  LR-int4-rdf
% y(29)  LR-int4-rdf2
% y(30)  LR-int4-rdf3
% y(31)  PB-int6i
% y(32)  PB-int6-rdf4i
% y(33)  RDF mRNA
% y(34)  PB-int6-rdfi
% y(35)  PB-int6-rdf2i
% y(36)  PB-int6-rdf3i
% y(37)  tetR mRNA
% y(38)  tetR

y0=[0*Dtot 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1*Dtot 0 0 0 0 0 0 0 0 0 0 0 0 0.4 0.06]; % init conditions for PxB
%y0=[1*Dtot 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0*Dtot 0 0 0 0 0 0 0 0 0.5 0 0 0 0 0]; % init conditions for LxR
%y0=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.01,1*Dtot,0,0,0,0,0,0,0,0,0.005,0,0,0,0.4,0.05]; % init conditions for PxB, closer to steady state
%y0=[1*Dtot,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0*Dtot,0,0,0,0,0,0,0,0,0.25,0,0,0,0.06,0.01]; % init conditions for LxR, closer to steady state
%y0=[0.6*Dtot,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.5,0.4*Dtot,0,0,0,0,0,0,0,0,0.25,0,0,0,0.06,0.01]; % init conditions for 60% LxR

options = odeset('MaxStep',0.1);

    %for Fig.S14:
    %period=18;
    %t=[0 24*6]; % time interval
    %[T, Y] = ode15s(@Model_tetR_110219,t,y0,options,Kii,Ki,Kir,Kb1,Kb2,Kb3,Kb4,Ks1,Ks2,Ks3,Ks4,Kr1,Kr2,Kmod,Kmodr,Ks01,Ks02,k_int,k_dil,Ktet,ara_on,ara_off,period,k_tscr,k_rna,ktet_tsl,krdf_tsl,kt);
    %y0=Y(end,:);  
    t=[0 24*4]; 
    [T, Y] = ode15s(@Model_tetR_110219,t,y0,options,Kii,Ki,Kir,Kb1,Kb2,Kb3,Kb4,Ks1,Ks2,Ks3,Ks4,Kr1,Kr2,Kmod,Kmodr,Ks01,Ks02,k_int,k_dil,Ktet,ara_on,ara_off,period,k_tscr,k_rna,ktet_tsl,krdf_tsl,kt);

    
LRt=Y(:,1)+Y(:,6)+Y(:,8)+Y(:,9)+Y(:,11)+Y(:,13)+Y(:,15)+Y(:,18)+Y(:,22)+Y(:,28)+Y(:,29)+Y(:,30);
PBt=Y(:,5)+Y(:,7)+Y(:,10)+Y(:,12)+Y(:,14)+Y(:,16)+Y(:,17)+Y(:,21)+Y(:,24)+Y(:,25)+Y(:,26)+Y(:,27)+Y(:,31)+Y(:,32)+Y(:,34)+Y(:,35)+Y(:,36);
int_tot=Y(:,2)+Y(:,19)+2*(Y(:,3)+Y(:,20)+Y(:,21)+Y(:,22)+Y(:,4)+Y(:,5)+Y(:,6)+Y(:,12)+Y(:,13))+4*(Y(:,7)+Y(:,8)+Y(:,9)+Y(:,10)+Y(:,11)+Y(:,14)+Y(:,15)+Y(:,16)+Y(:,17)+Y(:,18)+Y(:,28)+Y(:,29)+Y(:,30)+Y(:,25)+Y(:,26)+Y(:,27))+6*(Y(:,31)+Y(:,32)+Y(:,34)+Y(:,35)+Y(:,36));
rdf_tot=Y(:,23)+Y(:,19)+Y(:,20)+Y(:,21)+Y(:,22)+Y(:,25)+Y(:,28)+Y(:,34)+2*(Y(:,3)+Y(:,12)+Y(:,13)+Y(:,26)+Y(:,29)+Y(:,35))+3*(Y(:,27)+Y(:,30)+Y(:,36))+4*(Y(:,14)+Y(:,15)+Y(:,16)+Y(:,17)+Y(:,18)+Y(:,32));
DNA_rdf=Y(:,13)+Y(:,15)+Y(:,18)+Y(:,22)+Y(:,28)+Y(:,29)+Y(:,30)+Y(:,12)+Y(:,14)+Y(:,16)+Y(:,17)+Y(:,21)+Y(:,25)+Y(:,26)+Y(:,27)+Y(:,32)+Y(:,34)+Y(:,36);

pulse=[ ]; pulse1=[ ];
for i=1:length(T)
      Th(i)=T(i);
      pulse(i)=0.5*(tanh((Th(i)-period*floor(Th(i)/period)-ara_on)/kt)-tanh((Th(i)-period*floor(Th(i)/period)-ara_off)/kt));   
end


figure (1)
plot(T,pulse,'m:');
hold on;
plot(T,LRt/Dtot,'r');
hold on;
plot(T,PBt/Dtot,'b');
hold on;
plot(T,int_tot,'g');
hold on;
plot(T,rdf_tot,'k');
hold on;
plot(T,5*Y(:,38),'c');
hold on;
%title({'LR-red; BP-blue; tetR-cyan';'int-green; rdf-black'});

%figure (2)
%plot(Y(:,38),rdf_tot,'g');
%hold on;

