function Func = Model_tetR_110219(t,y,Kii,Ki,Kir,Kb1,Kb2,Kb3,Kb4,Ks1,Ks2,Ks3,Ks4,Kr1,Kr2,Kmod,Kmodr,Ks01,Ks02,k_int,k_dil,Ktet,ara_on,ara_off,period,k_tscr,k_rna,ktet_tsl,krdf_tsl,kt);

Func = zeros(38, 1);

puls=0.5*(tanh((t-period*floor(t/period)-ara_on)/kt)-tanh((t-period*floor(t/period)-ara_off)/kt));   

% y(1)   LR
% y(2)   int
% y(3)   int2-rdf2
% y(4)   int2
% y(5)   PB-int2
% y(6)   LR-int2
% y(7)   PB-int4
% y(8)   LR-int4
% y(9)   LR-int4 synapse second
% y(10)  PB-int4 synapse 
% y(11)  LR-int4 synapse first
% y(12)  PB-int2-rdf2
% y(13)  LR-int2-rdf2
% y(14)  PB-int4-rdf4
% y(15)  LR-int4-rdf4
% y(16)  PB-int4-rdf4 synapse second
% y(17)  PB-int4-rdf4 synapse first
% y(18)  LR-int4-rdf4 synapse
% y(19)  int-rdf
% y(20)  int2-rdf
% y(21)  PB-int2-rdf
% y(22)  LR-int2-rdf
% y(23)  rdf
% y(24)  PB
% y(25)  PB-int4-rdf
% y(26)  PB-int4-rdf2
% y(27)  PB-int4-rdf3
% y(28)  LR-int4-rdf
% y(29)  LR-int4-rdf2
% y(30)  LR-int4-rdf3
% y(31)  PB-int6i
% y(32)  PB-int6-rdf4i
% y(33)  RDF mRNA
% y(34)  PB-int6-rdfi
% y(35)  PB-int6-rdf2i
% y(36)  PB-int6-rdf3i
% y(37)  tetR mRNA
% y(38)  tetR

% kp - association rate; km - dissociation rate

kps01=40*60;
kps02=kps01;
kp=60*60;
kmii=Kii*kp;
kmir=Kir*kp;
kmb1=Kb1*kp;
kmb2=10*60;
kpb2=Kb2*kmb2;
kmb3=Kb3*kp;
kpb4=Kb4*kp;
kpi=3*60;
kmi=Ki*kpi;
kps1=0.8*60;
kps3=kps1;
kms01=Ks01*kps01;
kms02=Ks02*kps02;
kms1=Ks1*kps1;
kms3=Ks3*kps3;
kms2=0.0001*60;
kps2=Ks2*kms2;
kms4=0.005*60;
kps4=Ks4*kms4;
kpr=1*60; 
kmr1=kpr/Kr1;
kmr2=kpr/Kr2;
kpmod=1*60; 
kpmodr=kpmod; 
kmmod=kpmod/Kmod;
kmmodr=kpmodr/Kmodr;

Lr_t=y(1)+y(6)+y(8)+y(9)+y(11)+y(13)+y(15)+y(18)+y(22)+y(28)+y(29)+y(30);
Bp_t=y(24)+y(5)+y(7)+y(10)+y(12)+y(14)+y(16)+y(17)+y(21)+y(25)+y(26)+y(27)+y(31)+y(32)+y(34)+y(35)+y(36);

Func(1) = kpb2*y(6)-kmb2*y(1)*y(4)+kmb3*(y(13)+y(22))-kp*y(1)*(y(3)+y(20))+k_dil*(Lr_t-y(1));
Func(2) = k_int*puls+kmii*(2*y(4)+y(20))+kmir*y(19)-kp*(2*y(2)*y(2)+y(2)*y(19)+y(2)*y(23))-k_dil*y(2);
Func(3) = kp*(y(20)*y(23)+y(19)*y(19))-(kmir+kmii)*y(3)-kp*y(3)*(y(24)+y(12)+y(1)+y(13))-kps01*y(3)*(y(6)+y(22))-kps02*y(3)*(y(5)+y(21))+kpb4*(y(12)+y(14))+kms01*(y(29)+y(30))+kms02*(y(26)+y(27))+kmb3*(y(13)+y(15))-k_dil*y(3);
Func(4) = kp*y(2)*y(2)-kmii*y(4)-kp*y(4)*(y(23)+y(24)+y(5))-kmb2*y(4)*(y(1)+y(6))+kpb2*(y(6)+y(8))-kps01*y(4)*(y(13)+y(22))-kps02*y(4)*(y(12)+y(21))+kmir*y(20)+kmb1*(y(5)+y(7))+kms01*(y(28)+y(29))+kms02*(y(25)+y(26))-(kpi*y(4)*(y(7)+y(14)+y(25)+y(26)+y(27))-kmi*(y(31)+y(32)+y(34)+y(35)+y(36)))-k_dil*y(4);
Func(5) = kp*y(24)*y(4)-kmb1*y(5)-kp*y(5)*y(4)-kps02*y(5)*(y(20)+y(3))+kmb1*y(7)+kms02*(y(25)+y(26))-kp*y(23)*y(5)+kmir*y(21)-k_dil*y(5);
Func(6) = kmb2*y(4)*(y(1)-y(6))-kpb2*(y(6)-y(8))-kps01*y(6)*(y(20)+y(3))+kms01*(y(28)+y(29))-kp*y(23)*y(6)+kmir*y(22)-k_dil*y(6);
Func(7) = kp*y(5)*y(4)-kmb1*y(7)-kps1*y(7)+kms1*y(10)-(kpi*y(4)*y(7)-y(31)*kmi)-k_dil*y(7);
Func(8) = kmb2*y(6)*y(4)-kpb2*y(8)-kms2*y(8)+kps2*y(9)-k_dil*y(8);
Func(9) = kpmod*y(11)-kmmod*y(9)-kps2*y(9)+kms2*y(8)-k_dil*y(9);
Func(10) = kps1*y(7)-kms1*y(10)-kpr*y(10)+kmr1*y(11)-k_dil*y(10);
Func(11) = kpr*y(10)-kmr1*y(11)-kpmod*y(11)+kmmod*y(9)-k_dil*y(11);
Func(12) = kp*y(24)*y(3)-kpb4*y(12)+kp*y(21)*y(23)-kmir*y(12)-kp*y(12)*y(3)-kps02*y(12)*(y(4)+y(20))+kms02*(y(26)+y(27))+kpb4*y(14)-k_dil*y(12);
Func(13) = kp*y(1)*y(3)-kmb3*y(13)+kp*y(22)*y(23)-kmir*y(13)-kp*y(13)*y(3)-kps01*y(13)*(y(4)+y(20))+kms01*(y(29)+y(30))+kmb3*y(15)-k_dil*y(13);
Func(14) = kp*y(3)*y(12)-kpb4*y(14)+kps4*y(16)-kms4*y(14)-(kpi*y(4)*y(14)-y(32)*kmi)-k_dil*y(14);
Func(15) = kp*y(3)*y(13)-kmb3*y(15)-kps3*y(15)+kms3*y(18)-k_dil*y(15);
Func(16) = kpmodr*y(17)-kmmodr*y(16)-kps4*y(16)+kms4*y(14)-k_dil*y(16);
Func(17) = kpr*y(18)-kmr2*y(17)+kmmodr*y(16)-kpmodr*y(17)-k_dil*y(17);
Func(18) = kps3*y(15)-kms3*y(18)-kpr*y(18)+kmr2*y(17)-k_dil*y(18);
Func(19) = kp*(y(2)*y(23)-y(2)*y(19)-2*y(19)*y(19))-kmir*y(19)+kmii*(y(20)+2*y(3))-k_dil*y(19);
Func(20) = kp*(y(4)*y(23)+y(2)*y(19))-(kmir+kmii)*y(20)-kp*y(23)*y(20)+kmir*y(3)-kp*y(20)*(y(24)+y(1))-kps01*y(20)*(y(6)+y(22)+y(13))-kps02*y(20)*(y(5)+y(21)+y(12))+kpb4*y(21)+kms01*(y(28)+y(29)+y(30))+kms02*(y(25)+y(26)+y(27))+kmb3*y(22)-k_dil*y(20);
Func(21) = kp*y(24)*y(20)-kpb4*y(21)-kps02*y(21)*(y(4)+y(20)+y(3))+kms02*(y(25)+y(26)+y(27))+kp*y(23)*y(5)-kmir*y(21)-kp*y(21)*y(23)+kmir*y(12)-k_dil*y(21);
Func(22) = kp*y(1)*y(20)-kmb3*y(22)-kps01*y(22)*(y(20)+y(3)+y(4))+kms01*(y(28)+y(29)+y(30))+kp*y(23)*y(6)-kmir*y(22)-kp*y(22)*y(23)+kmir*y(13)-k_dil*y(22);
Func(23) = krdf_tsl*y(33)+kmir*(y(19)+y(20)+y(3)+y(21)+y(22)+y(12)+y(13))-kp*y(23)*(y(2)+y(4)+y(20)+y(5)+y(6)+y(21)+y(22))-k_dil*y(23);
Func(24) = kmb1*y(5)+kpb4*(y(12)+y(21))-kp*y(24)*(y(4)+y(20)+y(3))+k_dil*(Bp_t-y(24));
Func(25) = kps02*(y(4)*y(21)+y(20)*y(5))-y(25)*2*kms02-(kpi*y(4)*y(25)-y(34)*kmi)-k_dil*y(25);
Func(26) = kps02*(y(4)*y(12)+y(20)*y(21)+y(3)*y(5))-y(26)*3*kms02-(kpi*y(4)*y(26)-y(35)*kmi)-k_dil*y(26);
Func(27) = kps02*(y(20)*y(12)+y(3)*y(21))-y(27)*2*kms02-(kpi*y(4)*y(27)-y(36)*kmi)-k_dil*y(27);
Func(28) = kps01*(y(4)*y(22)+y(20)*y(6))-y(28)*2*kms01-k_dil*y(28);
Func(29) = kps01*(y(4)*y(13)+y(20)*y(22)+y(3)*y(6))-y(29)*3*kms01-k_dil*y(29);
Func(30) = kps01*(y(20)*y(13)+y(3)*y(22))-y(30)*2*kms01-k_dil*y(30);
Func(31) = kpi*y(4)*y(7)-y(31)*kmi-k_dil*y(31);
Func(32) = kpi*y(4)*y(14)-y(32)*kmi-k_dil*y(32);
Func(33) = k_tscr*Lr_t/(1+(y(38)/Ktet)^2)-k_rna*y(33);
Func(34) = kpi*y(4)*y(25)-y(34)*kmi-k_dil*y(34);
Func(35) = kpi*y(4)*y(26)-y(35)*kmi-k_dil*y(35);
Func(36) = kpi*y(4)*y(27)-y(36)*kmi-k_dil*y(36);
Func(37) = k_tscr*Bp_t-k_rna*y(37);
Func(38)= ktet_tsl*y(37)-k_dil*y(38);
%Func(38) = 0;

